function requestPage(pageUrl) {
  window.location.href = pageUrl;
}
